// Enum representing the three types of patient categories
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}